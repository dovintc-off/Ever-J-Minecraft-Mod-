package com.example;

import com.example.screen.ModSettingsScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class TemplateModClient implements ClientModInitializer {
    
    public static final class_2960 RAIN_ICON_TEXTURE = new class_2960(TemplateMod.MOD_ID, "textures/gui/rain_icon.png");
    
    public static final class_304 OPEN_SETTINGS_KEY = KeyBindingHelper.registerKeyBinding(
        new class_304(
            "key.ever-j.open_settings",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_O,
            "category.ever-j"
        )
    );
    
    private static boolean standKeyWasPressed = false;

    @Override
    public void onInitializeClient() {
        
        ModSettingsScreen.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (OPEN_SETTINGS_KEY.method_1436()) {
                client.method_1507(ModSettingsScreen.create(client.field_1755));
            }
            
            boolean isStandKeyPressed = class_3675.method_15987(
                client.method_22683().method_4490(), 
                ModSettingsScreen.standActivateKey.method_1444()
            );
            
            if (isStandKeyPressed && !standKeyWasPressed) {
                sendStandActiveMessage(client);
            }
            
            standKeyWasPressed = isStandKeyPressed;
        });

        HudRenderCallback.EVENT.register((class_332 context, float tickDelta) -> {
            if (!ModSettingsScreen.drawRainIcon) return;

            class_310 client = class_310.method_1551();
            if (client.field_1687 != null && client.field_1687.method_8419() && client.field_1687.method_27983() == class_1937.field_25179) {
                int size = ModSettingsScreen.rainIconSize;
                int x = client.method_22683().method_4486() - size - 5;
                int y = 10;
                context.method_25290(RAIN_ICON_TEXTURE, x, y, 0, 0, size, size, size, size);
            }
        });
    }

    private void sendStandActiveMessage(class_310 client){
        if (client.field_1724 != null){
            client.field_1724.method_7353(class_2561.method_43470("§6§lStand Active"), false);
        }
    }
}