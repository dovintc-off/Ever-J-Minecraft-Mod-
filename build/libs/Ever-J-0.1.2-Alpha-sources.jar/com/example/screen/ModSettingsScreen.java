package com.example.screen;

import com.example.TemplateMod;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import java.io.File;

public class ModSettingsScreen {
    
    // Путь к файлу конфигурации
    public static final File CONFIG_FILE = new File(
        System.getProperty("user.dir"), 
        "config/ever-j.json"
    );
    
    // Настройки по умолчанию
    public static boolean drawRainIcon = true;
    
    // Загрузка настроек
    public static void load() {
        if (CONFIG_FILE.exists()) {
            try {
                String content = new String(java.nio.file.Files.readAllBytes(CONFIG_FILE.toPath()));
                com.google.gson.JsonObject json = com.google.gson.JsonParser.parseString(content).getAsJsonObject();
                if (json.has("drawRainIcon")) {
                    drawRainIcon = json.get("drawRainIcon").getAsBoolean();
                }
                TemplateMod.LOGGER.info("[Ever J] Config loaded: drawRainIcon = " + drawRainIcon);
            } catch (Exception e) {
                TemplateMod.LOGGER.error("[Ever J] Failed to load config!", e);
            }
        } else {
            save();
        }
    }
    
    // Сохранение настроек
    public static void save() {
        try {
            CONFIG_FILE.getParentFile().mkdirs();
            com.google.gson.JsonObject json = new com.google.gson.JsonObject();
            json.addProperty("drawRainIcon", drawRainIcon);
            java.nio.file.Files.write(CONFIG_FILE.toPath(), json.toString().getBytes());
            TemplateMod.LOGGER.info("[Ever J] Config saved!");
        } catch (Exception e) {
            TemplateMod.LOGGER.error("[Ever J] Failed to save config!", e);
        }
    }
    
    // Создание экрана настроек через ClothConfig
    public static class_437 create(class_437 parent) {
        ConfigBuilder builder = ConfigBuilder.create()
            .setParentScreen(parent)
            .setTitle(class_2561.method_43471("screen.ever-j.settings.title"));
        
        builder.setSavingRunnable(ModSettingsScreen::save);
        
        ConfigCategory category = builder.getOrCreateCategory(class_2561.method_43471("category.ever-j.general"));
        
        // Переключатель (True/False)
        category.addEntry(builder.entryBuilder()
            .startBooleanToggle(class_2561.method_43471("screen.ever-j.settings.toggle"), drawRainIcon)
            .setDefaultValue(true)
            .setSaveConsumer(newValue -> drawRainIcon = newValue)  // ← Правильный метод!
            .build());
        
        return builder.build();
    }
}